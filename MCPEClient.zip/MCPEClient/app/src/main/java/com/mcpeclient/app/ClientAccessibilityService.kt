package com.mcpeclient.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Gives the overlay two abilities that need accessibility permission:
 *  - full-screen magnification (the Zoom button)
 *  - replaying a press at a saved screen point (the Q button)
 *
 * It does not read any screen content (no canRetrieveWindowContent).
 */
class ClientAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClientAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Magnify the whole screen around its centre. */
    fun zoomIn(scale: Float) {
        val dm = resources.displayMetrics
        val mc = magnificationController
        mc.setScale(scale.coerceIn(1.5f, 8f), true)
        mc.setCenter(dm.widthPixels / 2f, dm.heightPixels / 2f, true)
    }

    fun zoomOut() {
        magnificationController.reset(true)
    }

    /** Press at (x, y) for [durationMs]. A short duration is a tap, a long one a long-press. */
    fun press(x: Float, y: Float, durationMs: Long) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
