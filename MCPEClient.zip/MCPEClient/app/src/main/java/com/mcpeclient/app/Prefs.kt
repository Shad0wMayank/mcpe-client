package com.mcpeclient.app

import android.content.Context
import android.content.SharedPreferences

/** Tiny wrapper around SharedPreferences shared by the UI and the overlay service. */
object Prefs {
    const val NAME = "client_prefs"

    const val FPS = "mod_fps"
    const val CPS = "mod_cps"
    const val ZOOM = "mod_zoom"
    const val QBTN = "mod_q"
    const val EDIT = "edit_layout"

    const val ZOOM_LEVEL = "zoom_level_x10" // 15..80  => 1.5x..8.0x
    const val Q_HOLD = "q_hold_ms"          // 10..1500 ms
    const val Q_X = "q_x"
    const val Q_Y = "q_y"

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun bool(c: Context, key: String, def: Boolean): Boolean = sp(c).getBoolean(key, def)
    fun int(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)

    fun putBool(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
    fun putInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
}
