package com.mcpeclient.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Settings screen: permissions, module toggles, and the Start button that also opens Minecraft. */
class MainActivity : Activity() {

    companion object {
        const val MC_PACKAGE = "com.mojang.minecraftpe"
        const val TARGET_VERSION = "1.26.60.4"
        private const val REQ_CAPTURE = 42
        private const val REQ_NOTIF = 43
    }

    private lateinit var root: LinearLayout
    private lateinit var mcStatus: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var a11yStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(36), dp(16), dp(24))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF121212.toInt())
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)

        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        label("MCPE Client", 26f, true)
        label("Built for Minecraft Bedrock $TARGET_VERSION", 14f, false)
        mcStatus = label("", 14f, false)

        section("Setup")
        overlayStatus = label("", 14f, false)
        button("Grant overlay permission") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        a11yStatus = label("", 14f, false)
        button("Open accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        label(
            "If Android says the setting is restricted: Settings > Apps > MCPE Client > " +
                "menu (three dots) > Allow restricted settings, then try again.",
            12f, false
        )

        section("Modules")
        toggle("FPS counter", Prefs.FPS, true)
        toggle("CPS counter", Prefs.CPS, true)
        toggle("Zoom button (Z) - hold to zoom", Prefs.ZOOM, true)
        toggle("Q button", Prefs.QBTN, true)
        seek("Zoom level", Prefs.ZOOM_LEVEL, 15, 80, 30) { String.format("%.1fx", it / 10f) }
        seek("Q press length", Prefs.Q_HOLD, 10, 1500, 400) { "$it ms" }
        toggle("Edit layout (drag the HUD and buttons)", Prefs.EDIT, false)

        section("Run")
        button("Start client and open Minecraft") { startClient() }
        button("Stop client") {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        }
        label(
            "FPS needs screen-capture permission each time you start. If Android asks what to " +
                "share, choose \"Entire screen\".\n\n" +
                "Q button: once Minecraft is open, pull down the notification shade and tap " +
                "\"Set Q target\", then tap the exact spot the Q button should press.",
            12f, false
        )
    }

    private fun refreshStatus() {
        val info = try {
            packageManager.getPackageInfo(MC_PACKAGE, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
        mcStatus.text = when {
            info == null -> "Minecraft: not installed"
            info.versionName == TARGET_VERSION -> "Minecraft ${info.versionName}: matches target"
            else -> "Minecraft ${info.versionName}: differs from $TARGET_VERSION (the client does not " +
                "depend on game internals, so it should still work)"
        }
        overlayStatus.text = if (Settings.canDrawOverlays(this)) {
            "Overlay permission: granted"
        } else {
            "Overlay permission: NEEDED"
        }
        a11yStatus.text = if (ClientAccessibilityService.instance != null) {
            "Accessibility service: on"
        } else {
            "Accessibility service: off (needed for Zoom and Q)"
        }
    }

    // ------------------------------------------------------------------ start / stop

    private fun startClient() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Grant the overlay permission first")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
        if (Prefs.bool(this, Prefs.FPS, true)) {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
        } else {
            launchService(Activity.RESULT_CANCELED, null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode != Activity.RESULT_OK) toast("Screen capture declined: FPS will show --")
            launchService(resultCode, data)
        }
    }

    private fun launchService(code: Int, data: Intent?) {
        val i = Intent(this, OverlayService::class.java)
        i.putExtra(OverlayService.EXTRA_CODE, code)
        if (data != null) i.putExtra(OverlayService.EXTRA_DATA, data)
        startForegroundService(i)

        Handler(Looper.getMainLooper()).postDelayed({
            val launch = packageManager.getLaunchIntentForPackage(MC_PACKAGE)
            if (launch != null) startActivity(launch) else toast("Minecraft is not installed")
        }, 600)
    }

    // ------------------------------------------------------------------ view helpers

    private fun label(text: String, size: Float, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = size
        tv.setTextColor(Color.WHITE)
        if (bold) tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
        tv.setPadding(0, dp(6), 0, dp(2))
        root.addView(tv)
        return tv
    }

    private fun section(title: String) {
        val tv = label(title.uppercase(), 13f, true)
        tv.setTextColor(0xFF7CB7FF.toInt())
        tv.setPadding(0, dp(22), 0, dp(4))
    }

    private fun button(title: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = title
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        root.addView(b)
        return b
    }

    private fun toggle(title: String, key: String, def: Boolean) {
        val s = Switch(this)
        s.text = title
        s.setTextColor(Color.WHITE)
        s.isChecked = Prefs.bool(this, key, def)
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, checked -> Prefs.putBool(this, key, checked) }
        root.addView(s)
    }

    private fun seek(title: String, key: String, lo: Int, hi: Int, def: Int, fmt: (Int) -> String) {
        val tv = label("", 14f, false)
        val current = Prefs.int(this, key, def).coerceIn(lo, hi)
        tv.text = "$title: ${fmt(current)}"
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = current - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                Prefs.putInt(this@MainActivity, key, v)
                tv.text = "$title: ${fmt(v)}"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sb)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
