package com.mcpeclient.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Draws the HUD (FPS + CPS), the Zoom button and the Q button on top of Minecraft.
 *
 * - CPS: a 1x1 window with FLAG_WATCH_OUTSIDE_TOUCH receives ACTION_OUTSIDE for every
 *   touch-down anywhere else on screen. Counted over the last second.
 * - FPS: a tiny mirrored virtual display (MediaProjection). A frame is produced each time the
 *   screen content changes, so frames/second approximates the game's frame rate. It is an
 *   estimate, capped at the display refresh rate.
 * - Zoom / Q: delegated to [ClientAccessibilityService].
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.mcpeclient.app.STOP"
        const val ACTION_CALIBRATE = "com.mcpeclient.app.CALIBRATE"
        const val EXTRA_CODE = "capture_code"
        const val EXTRA_DATA = "capture_data"

        private const val CHANNEL_ID = "client"
        private const val NOTIF_ID = 1
        private const val KEY_HUD = "hud"
        private const val KEY_ZOOM = "zoombtn"
        private const val KEY_Q = "qbtn"

        private const val BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        // Android 12+ blocks touches that pass through overlays with alpha above 0.8.
        private const val OVERLAY_ALPHA = 0.8f

        @Volatile
        var running = false
            private set
    }

    private class Element(val key: String, val view: View, val lp: WindowManager.LayoutParams)

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val elements = mutableListOf<Element>()
    private var hud: TextView? = null
    private var watcher: View? = null
    private var calibrationView: View? = null
    private var isForeground = false
    private var zoomed = false

    // Main thread only.
    private val clicks = ArrayDeque<Long>()
    private var lastOwnTouch = 0L

    // FPS capture.
    private val frameCount = AtomicInteger()
    private var captureThread: HandlerThread? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null

    @Volatile
    private var fpsCapturing = false
    private var fps = 0
    private var lastTick = 0L

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        main.post { refreshElements() }
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            while (clicks.isNotEmpty() && now - clicks.first() > 1000) clicks.removeFirst()
            if (fpsCapturing) {
                val n = frameCount.getAndSet(0)
                val dt = now - lastTick
                if (dt > 0) fps = (n * 1000f / dt).roundToInt()
            }
            lastTick = now
            updateHud()
            main.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Client status", NotificationManager.IMPORTANCE_LOW)
        )
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefsListener)
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        }
        val wantCapture = code == Activity.RESULT_OK && data != null && projection == null

        if (!isForeground) {
            if (!promoteToForeground(wantCapture)) {
                stopSelf()
                return START_NOT_STICKY
            }
        }

        if (!running) {
            running = true
            buildOverlay()
            main.post(tick)
        }

        if (wantCapture && data != null) startCapture(code, data)
        if (intent?.action == ACTION_CALIBRATE) showCalibration()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
        if (zoomed) ClientAccessibilityService.instance?.zoomOut()
        for (e in elements) removeQuietly(e.view)
        elements.clear()
        watcher?.let { removeQuietly(it) }
        watcher = null
        calibrationView?.let { removeQuietly(it) }
        calibrationView = null
        stopCapture()
        running = false
        super.onDestroy()
    }

    // ------------------------------------------------------------------ foreground

    private fun promoteToForeground(withProjection: Boolean): Boolean {
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val calPi = PendingIntent.getService(
            this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_CALIBRATE),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("MCPE Client is running")
            .setContentText("Pull down and tap \"Set Q target\" while Minecraft is open")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Set Q target", calPi).build())
            .addAction(Notification.Action.Builder(0, "Stop", stopPi).build())
            .build()

        return try {
            when {
                Build.VERSION.SDK_INT >= 34 -> startForeground(
                    NOTIF_ID, notification,
                    if (withProjection) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
                Build.VERSION.SDK_INT >= 29 -> startForeground(
                    NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
                )
                else -> startForeground(NOTIF_ID, notification)
            }
            isForeground = true
            true
        } catch (e: Exception) {
            toast("Could not start the client: ${e.javaClass.simpleName}")
            false
        }
    }

    // ------------------------------------------------------------------ overlay

    private fun buildOverlay() {
        val hudView = pill("FPS --  |  CPS 0")
        hud = hudView
        addElement(KEY_HUD, hudView, dp(8), dp(8), null, null)

        addElement(KEY_ZOOM, roundButton("Z"), dp(16), dp(120), onDown = { zoomDown() }, onUp = { zoomUp() })
        addElement(KEY_Q, roundButton("Q"), dp(16), dp(190), onDown = { qPressed() }, onUp = null)

        val w = View(this)
        w.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) onOutsideTouch()
            false
        }
        val lp = WindowManager.LayoutParams(
            1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.alpha = OVERLAY_ALPHA
        wm.addView(w, lp)
        watcher = w

        refreshElements()
    }

    private fun addElement(
        key: String, view: View, defX: Int, defY: Int,
        onDown: (() -> Unit)?, onUp: (() -> Unit)?
    ) {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.alpha = OVERLAY_ALPHA
        lp.x = Prefs.int(this, "${key}_x", defX)
        lp.y = Prefs.int(this, "${key}_y", defY)
        val el = Element(key, view, lp)

        view.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (Prefs.bool(this@OverlayService, Prefs.EDIT, false)) {
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = e.rawX; downY = e.rawY
                            startX = el.lp.x; startY = el.lp.y
                        }
                        MotionEvent.ACTION_MOVE -> {
                            el.lp.x = startX + (e.rawX - downX).toInt()
                            el.lp.y = startY + (e.rawY - downY).toInt()
                            try { wm.updateViewLayout(v, el.lp) } catch (_: Exception) {}
                        }
                        MotionEvent.ACTION_UP -> {
                            Prefs.putInt(this@OverlayService, "${el.key}_x", el.lp.x)
                            Prefs.putInt(this@OverlayService, "${el.key}_y", el.lp.y)
                        }
                    }
                    return true
                }
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        lastOwnTouch = SystemClock.uptimeMillis()
                        v.alpha = 0.6f
                        onDown?.invoke()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.alpha = 1f
                        onUp?.invoke()
                    }
                }
                return true
            }
        })

        wm.addView(view, lp)
        elements.add(el)
    }

    /** Applies module toggles and edit mode to the windows. */
    private fun refreshElements() {
        val edit = Prefs.bool(this, Prefs.EDIT, false)
        for (e in elements) {
            val enabled = when (e.key) {
                KEY_HUD -> Prefs.bool(this, Prefs.FPS, true) || Prefs.bool(this, Prefs.CPS, true)
                KEY_ZOOM -> Prefs.bool(this, Prefs.ZOOM, true)
                else -> Prefs.bool(this, Prefs.QBTN, true)
            }
            e.view.visibility = if (enabled) View.VISIBLE else View.GONE
            val touchable = edit || e.key != KEY_HUD
            e.lp.flags = if (touchable) BASE_FLAGS
            else BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { wm.updateViewLayout(e.view, e.lp) } catch (_: Exception) {}
        }
        if (!Prefs.bool(this, Prefs.FPS, true)) stopCapture()
        updateHud()
    }

    private fun updateHud() {
        val parts = ArrayList<String>(2)
        if (Prefs.bool(this, Prefs.FPS, true)) parts.add(if (fpsCapturing) "FPS $fps" else "FPS --")
        if (Prefs.bool(this, Prefs.CPS, true)) parts.add("CPS ${clicks.size}")
        hud?.text = parts.joinToString("  |  ")
    }

    // ------------------------------------------------------------------ actions

    private fun onOutsideTouch() {
        val t = SystemClock.uptimeMillis()
        // Ignore touches that landed on our own buttons (both windows see the event).
        main.postDelayed({
            if (abs(lastOwnTouch - t) > 100) clicks.addLast(t)
        }, 40)
    }

    private fun zoomDown() {
        val svc = ClientAccessibilityService.instance
        if (svc == null) {
            toast("Turn on the MCPE Client accessibility service first")
            return
        }
        zoomed = true
        svc.zoomIn(Prefs.int(this, Prefs.ZOOM_LEVEL, 30) / 10f)
    }

    private fun zoomUp() {
        if (!zoomed) return
        zoomed = false
        ClientAccessibilityService.instance?.zoomOut()
    }

    private fun qPressed() {
        val x = Prefs.int(this, Prefs.Q_X, -1)
        val y = Prefs.int(this, Prefs.Q_Y, -1)
        if (x < 0 || y < 0) {
            toast("Set the Q target first: pull down the notification and tap \"Set Q target\"")
            return
        }
        val svc = ClientAccessibilityService.instance
        if (svc == null) {
            toast("Turn on the MCPE Client accessibility service first")
            return
        }
        svc.press(x.toFloat(), y.toFloat(), Prefs.int(this, Prefs.Q_HOLD, 400).toLong())
    }

    /** Full-screen "tap where Q should press" overlay. */
    private fun showCalibration() {
        if (calibrationView != null) return
        val v = TextView(this)
        v.text = "Tap the exact spot Q should press\n(for example the drop action in your layout)"
        v.setTextColor(Color.WHITE)
        v.textSize = 18f
        v.gravity = Gravity.CENTER
        v.setBackgroundColor(0x88000000.toInt())
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                Prefs.putInt(this, Prefs.Q_X, e.rawX.toInt())
                Prefs.putInt(this, Prefs.Q_Y, e.rawY.toInt())
                main.post {
                    calibrationView?.let { removeQuietly(it) }
                    calibrationView = null
                }
                toast("Q target saved")
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        calibrationView = v
    }

    // ------------------------------------------------------------------ FPS capture

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            toast("FPS capture unavailable: ${e.javaClass.simpleName}")
            null
        } ?: return

        projection = mp
        val thread = HandlerThread("fps-capture").also { it.start() }
        captureThread = thread
        val handler = Handler(thread.looper)

        // Android 14+: a callback must be registered before creating the virtual display.
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopCapture() }
            }
        }, handler)

        val dm = resources.displayMetrics
        val w = max(64, dm.widthPixels / 8)
        val h = max(64, dm.heightPixels / 8)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            try { rd.acquireLatestImage()?.close() } catch (_: Exception) {}
            frameCount.incrementAndGet()
        }, handler)
        reader = r

        virtualDisplay = try {
            mp.createVirtualDisplay(
                "mcpe-client-fps", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
            )
        } catch (e: Exception) {
            toast("FPS capture unavailable: ${e.javaClass.simpleName}")
            null
        }
        if (virtualDisplay == null) {
            stopCapture()
            return
        }
        frameCount.set(0)
        lastTick = SystemClock.uptimeMillis()
        fpsCapturing = true
    }

    private fun stopCapture() {
        fpsCapturing = false
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        val p = projection
        projection = null
        try { p?.stop() } catch (_: Exception) {}
        captureThread?.quitSafely()
        captureThread = null
    }

    // ------------------------------------------------------------------ helpers

    private fun pill(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 14f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(10), dp(5), dp(10), dp(5))
        val bg = GradientDrawable()
        bg.setColor(0x99000000.toInt())
        bg.cornerRadius = dp(8).toFloat()
        tv.background = bg
        return tv
    }

    private fun roundButton(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 18f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.minWidth = dp(52)
        tv.minHeight = dp(52)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xAA222222.toInt())
        bg.setStroke(dp(2), Color.WHITE)
        tv.background = bg
        return tv
    }

    private fun removeQuietly(v: View) {
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show() }
    }
}
