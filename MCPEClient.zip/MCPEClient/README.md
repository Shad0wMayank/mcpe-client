# MCPE Client

An Android app that adds a HUD and shortcuts on top of Minecraft Bedrock (built for 1.26.60.4).
It never touches the game's files or memory, so it does not depend on game-version offsets.

| Feature | How it works |
|---|---|
| **CPS** | A 1x1 overlay window receives `ACTION_OUTSIDE` for every touch-down on screen. Clicks in the last second are shown. Counts all screen touches (attack/place taps, and also starting to move with the joystick). |
| **FPS** | A tiny mirrored virtual display (screen capture). Frames per second of screen updates is shown, which approximates the game's FPS. It is an **estimate**, capped at your display's refresh rate. |
| **Zoom (Z button)** | Hold the Z button to magnify the whole screen (Android accessibility magnification). Zoom level is adjustable (1.5x to 8x). |
| **Q button** | Replays a press at a spot you choose (accessibility gesture). Use it for the drop action in your control layout. |

## Build the APK

### Option A: GitHub Actions (no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, choose **Build APK**, press **Run workflow**.
3. When it finishes, download the artifact **MCPE-Client-debug-apk**, unzip it, and install `app-debug.apk` on your phone.

### Option B: Android Studio
1. Open this folder in Android Studio (Hedgehog or newer, JDK 17).
2. Let Gradle sync, then **Build > Build APK(s)**.
3. The APK is in `app/build/outputs/apk/debug/`.

## First-time setup on the phone
1. Install the APK (allow "install unknown apps" for your file manager or browser).
2. Open **MCPE Client** and press **Grant overlay permission**.
3. Press **Open accessibility settings**, find **MCPE Client**, turn it on.
   If Android blocks it ("restricted setting"): Settings > Apps > MCPE Client > three-dot menu > **Allow restricted settings**, then try again.
4. Press **Start client and open Minecraft**. Allow screen capture for FPS (choose **Entire screen** if asked).
5. In Minecraft, pull down the notification shade, tap **Set Q target**, then tap the exact spot the Q button should press.

Turn on **Edit layout** in the app to drag the HUD, Z and Q buttons where you want them.

## Notes and limits
- This project was written without being compiled or tested on a device in the authoring environment (no Android SDK there). If the build reports an error, send the log and it can be fixed quickly.
- Zoom magnifies the entire screen including controls (it is not an in-game FOV zoom).
- The FPS counter costs a little performance and needs the capture permission each time you start.
- Use on public servers at your own risk; follow each server's rules.
